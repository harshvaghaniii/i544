#!/usr/bin/env ts-node
/** *** IMPORTANT NOTE ***

ALL FUNCTIONS BELOW MUST BE IMPLEMENTED WITHOUT USING RECURSION OR **ANY**
DESTRUCTIVE OPERATIONS.

Some consequences:

  + *NO LOOPS* of any kind.

  + Only const declarations.

  + Use Array methods like .map() and .reduce() and Array.from({length:n})
    (to create an empty n-element array).

  + No destructive Array methods like .push() (use .concat() instead).

  + You may use destructive methods like .reverse() as long as you
    use it only for its return value and not for its side-effects (this is
    because ts-node does not allow the use of the newer non-destructive
    .toReversed()).

  + Use String methods like split().

  + Use RegExp methods.

More details are in the .<restrictions.html> document linked from the
main assignment.

When fully implemented, running this file should result in the LOG
linked from the main assignment.

*/
/** #1: "4-points"
 *  Returns strings with each element reversed.
 */
declare function revStrings(strings: string[]): string[];
/** #2: "4-points"
 #  Return all words in str which start with an uppercase letter A-Z.
 *  Note that for this exercise and subsequent exercises, a word is
 *  defined to be a maximal sequence of length > 1 containing
 *  consecutive \w characters.
 */
declare function getCapitalizedWords(str: string): string[];
/** #3: "4-points"
 #  Return all words in str which start with are camel-cased.
 *  A word is defined to be camel-cased if an uppercase letter A-Z
 *  immediately follows a lower-case letter a-z.
 */
declare function getCamelCasedWords(str: string): string[];
/** #4: "5-points"
 *  Given a positive integer n > 0, return the list
 *  [1, 2, ..., (n-1), n, (n-1), ..., 2, ].
 */
declare function upDown1n1(n: number): number[];
/** #5: "5-points"
 *  Given a list of distinct numbers, return true iff
 *  perms is a permutation of it.
 */
declare function isPermutation(list: number[], perms: number[]): boolean;
/** #6: "5-points"
 *  Given a number x and an integer n >= 0, return x**n
 *  without using **.
 */
declare function pow(x: number, n: number): number;
/** #7: "5-points"
 *  Return x ** x ** x ** ... ** x with h x's.
 *  (i.e. the tetration of x to height h; see
 *  <https://en.wikipedia.org/wiki/Tetration>
 */
declare function tetrate(x: number, h: number): number;
/** #8: "5-points"
 *  A number in an arbitrary integer base b is represented by
 *  a list of "b-digits" [ d_0, d_1, d_2, ... ] where each d_i < b
 *  and has weight b**i.
 *
 *  For example, the decimal number 123 is represented by
 *  list of digits [3, 2, 1]; the hexadecimal number 0xabc is represented
 *  by the list of "hexadecimal-digits" [12, 11, 10].
 *
 *  Return the value of the number represented by list bDigits using
 *  base b.
 */
declare function digitsNumberValueInBase(b: number, bDigits: number[]): number;
/** #9: "7-points"
 *  If n is an integer, then JS allows n.toString(b) to return
 *  the string representation of n in base b, where 2 <= b <= 36.
 *  See <https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Number/toString>.
 *
 *  Return the value of string str in base b.
 */
declare function bStringValue(bString: string, b: number): number;
/** #10: "9-points"
 *  Given a list ls of 2n elements, return a n-element
 *  list of the consecutive pairs of ls.
 */
declare function listPairs<T>(ls: T[]): T[][];
/** #11: "5-points"
 *  Given a list ls of n*m elements, return a m-element
 *  list of the consecutive n-tuples of ls.
 */
declare function nTuples<T>(ls: T[], n: number): T[][];
/** #12: "9-points"
 *  Return the value of e approximated as the sum of 1/k! for
 *  k in 1, 2, 3, ..., n.
 *  See <https://en.wikipedia.org/wiki/E_(mathematical_constant)>
 */
declare function e(n: number): number;
declare const _default: {
    revStrings: typeof revStrings;
    getCapitalizedWords: typeof getCapitalizedWords;
    getCamelCasedWords: typeof getCamelCasedWords;
    upDown1n1: typeof upDown1n1;
    isPermutation: typeof isPermutation;
    pow: typeof pow;
    tetrate: typeof tetrate;
    digitsNumberValueInBase: typeof digitsNumberValueInBase;
    bStringValue: typeof bStringValue;
    listPairs: typeof listPairs;
    nTuples: typeof nTuples;
    e: typeof e;
};
export default _default;
//# sourceMappingURL=hw1-sol.d.ts.map