# dependencies for specific project

apt install -y python3

npm install -g typescript
npm install -g ts-node

apt install -y jq

apt install -y emacs



